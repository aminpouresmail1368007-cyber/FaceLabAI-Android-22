# FACE LAB PRO+ 22.0 — Android Source

Android test build source for FACE LAB PRO+ 22.0.

## What is included
- Personal photo / front-camera workflow
- ML Kit face detection and dense green face mapping overlay
- Photo-mapped simulator zones and syringe hit-testing
- Photo Mapping Status with face quality score and detected-point count
- Photo QA mode: validate alignment with 3 successful safe-zone interactions
- Automatic Before → After reveal after a successful simulator interaction
- Draggable Before/After comparison
- Personalized landmark-guided 3D face visualization using the user's photo texture
- Academy lessons open as full lesson sheets with checkpoints
- Offline UI and local progress storage
- Package: `com.facelab.ai`
- Creator: Dr. Amin Pourasmaeil / دکتر امین پوراسماعیل

## Android test flow
1. Install a debug APK generated from this project.
2. Tap **Practice on My Photo** and take a front-facing photo.
3. Confirm green face points appear on the user's own face.
4. Check **Photo Mapping Status**.
5. Tap **Photo QA** and register 3 successful interactions on the green training target.
6. Confirm status changes to **PHOTO VERIFIED**.
7. Check Before/After and the 3D view.

## Safety scope
Educational visual simulation only. It does not provide real injection depth, dose, angle, or clinical procedural coordinates.
