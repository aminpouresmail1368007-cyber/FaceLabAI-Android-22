# FACE LAB 23.0.1 Android build test

Expected source root: `FaceLabAI_Android_23_0`

```bash
gradle :app:assembleDebug --no-daemon
```

Expected debug APK:
`app/build/outputs/apk/debug/app-debug.apk`
