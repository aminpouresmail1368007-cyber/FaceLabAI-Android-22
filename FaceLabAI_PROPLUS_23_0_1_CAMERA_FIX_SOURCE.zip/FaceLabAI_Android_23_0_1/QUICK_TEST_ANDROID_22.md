# FACE LAB 23.0.1 quick device test

1. Install debug APK.
2. Open Simulator and verify normal Face Lock still works.
3. Tap **CLINICAL 3D SCAN**.
4. Accept camera permission and ARCore install/update if prompted.
5. If Depth API is unsupported, verify the app explicitly says no real scan will be generated.
6. On a Depth-supported device, scan a still face with the rear camera for ~10 s.
7. Verify returned viewer says `ARCORE DEPTH • METRIC POINT CLOUD` and can rotate/zoom.
8. Verify QC point count / depth frames / sweep are shown.
9. Verify no clinical dose, injection depth, or procedural coordinates are presented.
