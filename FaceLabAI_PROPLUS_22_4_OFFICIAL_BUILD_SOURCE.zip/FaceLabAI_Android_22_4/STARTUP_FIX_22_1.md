# FACE LAB PRO+ 22.1 — Startup Fix

- Splash screen now has a fail-safe timeout.
- Startup modules initialize independently so one module error cannot block the app.
- AndroidX and BuildConfig are enabled in the source project.
- Debug build version: 22.1.
