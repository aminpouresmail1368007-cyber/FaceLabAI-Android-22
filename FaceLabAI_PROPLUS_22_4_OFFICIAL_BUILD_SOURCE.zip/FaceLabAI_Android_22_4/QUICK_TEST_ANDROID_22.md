# FACE LAB PRO+ 22.0 — Android Quick Test

- [ ] App opens without crash.
- [ ] Camera opens from Practice on My Photo.
- [ ] A front-facing photo replaces the bundled model.
- [ ] Green landmarks/contours appear on the same photographed face.
- [ ] Photo Mapping Status shows a non-zero detected-point count.
- [ ] Photo QA starts.
- [ ] 3 safe-zone interactions change QA to PHOTO VERIFIED.
- [ ] Successful simulated injection visibly changes the After preview.
- [ ] Before/After slider can be dragged manually.
- [ ] 3D view rotates and uses the same personal face texture.
- [ ] Academy lessons open and checkpoint can be saved.
