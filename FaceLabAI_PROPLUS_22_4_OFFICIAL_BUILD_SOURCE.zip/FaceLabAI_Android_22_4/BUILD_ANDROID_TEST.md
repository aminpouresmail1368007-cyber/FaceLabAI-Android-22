# Build the Android test APK

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

The debug build uses the package suffix `.test22`, so it can be installed next to an older FACE LAB build without overwriting it.

GitHub Actions output:
`FACE-LAB-PROPLUS-22-TEST.apk`

To build locally you need Android SDK 35, Build Tools 35.0.0, Gradle 8.10.2 and JDK 17.

Command:
`gradle :app:assembleDebug --no-daemon`
