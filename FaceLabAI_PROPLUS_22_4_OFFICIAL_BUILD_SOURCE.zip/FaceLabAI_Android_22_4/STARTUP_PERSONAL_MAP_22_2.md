# FACE LAB PRO+ 22.2 — Personal Mapping Update

- Lip target now locks to the detected personal mouth/lip landmark and nearby lip contour rather than a generic face-box position.
- Virtual syringe starts aligned to the active visual target with region-specific UI orientation (visual simulation only).
- Main photo supports press-and-hold Before and release-to-After comparison.
- 3D visualization now fits the mesh silhouette to detected face contours and landmarks for a more personalized shape.
- This remains an educational visual simulator and does not provide real injection depth, dose, procedural angle, or clinical coordinates.
