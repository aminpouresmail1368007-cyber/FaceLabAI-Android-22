# FACE LAB PRO+ 22.0 — Android Source

Android test build source for FACE LAB PRO+ 22.0.

## What is included
- Personal photo / front-camera workflow
- ML Kit face detection and dense green face mapping overlay
- Photo-mapped simulator zones and syringe hit-testing
- Photo Mapping Status with face quality score and detected-point count
- Photo QA mode: validate alignment with 3 successful safe-zone interactions
- Automatic Before → After reveal after a successful simulator interaction
- Draggable Before/After comparison
- Personalized landmark-guided 3D face visualization using the user's photo texture
- Academy lessons open as full lesson sheets with checkpoints
- Offline UI and local progress storage
- Package: `com.facelab.ai`
- Creator: Dr. Amin Pourasmaeil / دکتر امین پوراسماعیل

## Android test flow
1. Install a debug APK generated from this project.
2. Tap **Practice on My Photo** and take a front-facing photo.
3. Confirm green face points appear on the user's own face.
4. Check **Photo Mapping Status**.
5. Tap **Photo QA** and register 3 successful interactions on the green training target.
6. Confirm status changes to **PHOTO VERIFIED**.
7. Check Before/After and the 3D view.

## Safety scope
Educational visual simulation only. It does not provide real injection depth, dose, angle, or clinical procedural coordinates.


## 22.4 changes
- Fixed photo coordinate mapping to match the visible 42% object-position crop.
- Improved lip contour isolation and visual target placement.
- Visual syringe tip snaps to the selected simulation target.
- Added Personalized Visual Balance (1–5 visual units). These are simulation intensity levels, not medication dose or clinical injection recommendations.


## 22.4 overlay sync fix
- Added exact rendered-image sync for overlay placement
- Added named lip contours from ML Kit for better lip target placement
- Shifted non-lip region targets using personalized detected anchors


## 22.4.1 hotfix
- Fixed a JavaScript parse error that prevented simulator buttons from responding.
- Preserves 22.4 rendered-photo overlay alignment and personalized face anchors.


## FACE LAB PRO+ 22.6 — Exact Face Lock
- Normalizes camera/gallery photos through canvas before ML Kit detection so display pixels and detected coordinates use the same orientation/crop space.
- Removes approximate green targets for personal photos. If exact mapping fails, targets and syringe are hidden and the app asks for a new photo.
- Lips are built from actual mouth-left/right plus upper/lower lip contours.
- Chin, glabella, midface, jawline and temple training overlays are derived from detected face anchors/contours.
- Overlays resync after layout/rotation changes.
- Reservoir language is simulation-only and no clinical dose is provided.
