package com.facelab.ai;

public final class ClinicalScanStore {
    private static String lastResult;
    private ClinicalScanStore() {}
    public static synchronized void putResult(String json) { lastResult = json; }
    public static synchronized String takeResult() { String x = lastResult; lastResult = null; return x; }
    public static synchronized void clear() { lastResult = null; }
}
