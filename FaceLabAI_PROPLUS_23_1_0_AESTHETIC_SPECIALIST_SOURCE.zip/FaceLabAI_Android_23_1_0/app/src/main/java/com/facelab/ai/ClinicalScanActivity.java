package com.facelab.ai;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Image;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.ar.core.ArCoreApk;
import com.google.ar.core.Camera;
import com.google.ar.core.CameraIntrinsics;
import com.google.ar.core.Config;
import com.google.ar.core.Coordinates2d;
import com.google.ar.core.Frame;
import com.google.ar.core.Pose;
import com.google.ar.core.Session;
import com.google.ar.core.TrackingState;
import com.google.ar.core.exceptions.CameraNotAvailableException;
import com.google.ar.core.exceptions.NotYetAvailableException;
import com.google.ar.core.exceptions.UnavailableApkTooOldException;
import com.google.ar.core.exceptions.UnavailableArcoreNotInstalledException;
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException;
import com.google.ar.core.exceptions.UnavailableSdkTooOldException;
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * FACE LAB 23.0.2 research depth scanner.
 *
 * Uses ARCore Depth API when the device supports it. This captures metric depth samples and
 * accumulates them in a common AR coordinate system. It is deliberately labeled research /
 * visualization: it is not a validated diagnostic or treatment-planning medical device.
 */
public class ClinicalScanActivity extends Activity implements GLSurfaceView.Renderer {
    private static final int CAMERA_PERMISSION_REQUEST = 8801;
    private static final long TARGET_SCAN_MS = 12_000L;
    private static final long MAX_SCAN_MS = 18_000L;
    private static final long DEPTH_WARMUP_MS = 1_500L;
    private static final int MAX_RETURN_POINTS = 8000;

    private GLSurfaceView glView;
    private Session session;
    private boolean installRequested = false;
    private boolean depthSupported = false;
    private boolean scanning = false;
    private boolean finishing = false;
    private long scanStartedAt = 0L;
    private long firstValidDepthAt = 0L;
    private long lastUiUpdate = 0L;
    private int renderedFrames = 0;
    private int depthFrames = 0;
    private int skippedDepthFrames = 0;
    private Pose initialPose = null;
    private float maxCameraTravelM = 0f;
    private final ArrayList<float[]> rawPoints = new ArrayList<>();

    private TextView status;
    private TextView metric;
    private TextView badge;
    private Button scanButton;
    private ProgressBar progress;

    private int cameraTextureId = -1;
    private int bgProgram = 0;
    private int bgPos = -1, bgUv = -1, bgSampler = -1;
    private FloatBuffer quadPos;
    private FloatBuffer quadUv;
    private final float[] quadCoords = new float[]{-1f,-1f, 1f,-1f, -1f,1f, 1f,1f};
    private final float[] uvCoords = new float[8];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(2, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(2, 9, 12));
        buildUi();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 9, 12));

        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setPreserveEGLContextOnPause(true);
        glView.setRenderer(this);
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(glView, new FrameLayout.LayoutParams(-1, -1));

        View oval = new View(this);
        oval.setBackground(makeOvalDrawable());
        FrameLayout.LayoutParams ovalLp = new FrameLayout.LayoutParams(dp(250), dp(330), Gravity.CENTER);
        ovalLp.topMargin = -dp(20);
        root.addView(oval, ovalLp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(18), dp(16), dp(18), dp(12));
        top.setBackgroundColor(Color.argb(195, 2, 12, 16));
        badge = text("CLINICAL 3D SCAN • DEPTH", 14, Color.rgb(92, 244, 234), true);
        status = text("در حال بررسی Depth API…", 13, Color.WHITE, true);
        metric = text("صورت داخل بیضی • فاصله پیشنهادی 50–90 cm • دوربین پشت", 11, Color.rgb(180, 205, 209), false);
        top.addView(badge); top.addView(status); top.addView(metric);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(top, topLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(18), dp(12), dp(18), dp(20));
        bottom.setBackgroundColor(Color.argb(215, 2, 12, 16));

        TextView guide = text("برای اسکن واقعی، یک نفر با دوربین پشت گوشی آرام از چپ به راست دور صورت حرکت کند. سر ثابت بماند.", 11, Color.rgb(210, 230, 232), false);
        guide.setGravity(Gravity.CENTER);
        bottom.addView(guide);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000); progress.setProgress(0);
        LinearLayout.LayoutParams progLp = new LinearLayout.LayoutParams(-1, dp(8));
        progLp.setMargins(0, dp(12), 0, dp(10));
        bottom.addView(progress, progLp);

        scanButton = new Button(this);
        scanButton.setText("شروع اسکن عمقی ۱۰ ثانیه‌ای");
        scanButton.setTextColor(Color.rgb(3, 18, 22));
        scanButton.setTextSize(13);
        scanButton.setAllCaps(false);
        scanButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(84, 238, 231)));
        scanButton.setEnabled(false);
        scanButton.setOnClickListener(v -> {
            if (!scanning) beginScan(); else finishScan(false);
        });
        bottom.addView(scanButton, new LinearLayout.LayoutParams(-1, dp(52)));

        Button cancel = new Button(this);
        cancel.setText("لغو و بازگشت"); cancel.setAllCaps(false); cancel.setTextColor(Color.rgb(190, 210, 214));
        cancel.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(8, 25, 30)));
        cancel.setOnClickListener(v -> finishWithFailure("cancelled", "اسکن لغو شد"));
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(-1, dp(44)); cancelLp.topMargin = dp(6);
        bottom.addView(cancel, cancelLp);

        TextView disclaimer = text("Research visualization only • Metric depth is device-derived and is not a validated medical measurement.", 9, Color.rgb(120, 145, 151), false);
        disclaimer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams disLp = new LinearLayout.LayoutParams(-1, -2); disLp.topMargin = dp(8);
        bottom.addView(disclaimer, disLp);

        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(bottom, bottomLp);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int b = 0, t = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                b = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                t = insets.getInsets(WindowInsets.Type.statusBars()).top;
            }
            top.setPadding(dp(18), dp(12) + t, dp(18), dp(12));
            bottom.setPadding(dp(18), dp(12), dp(18), dp(16) + b);
            return insets;
        });
        setContentView(root);
    }

    private android.graphics.drawable.Drawable makeOvalDrawable() {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setColor(Color.TRANSPARENT);
        gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        gd.setStroke(dp(2), Color.argb(190, 85, 242, 231));
        return gd;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(2), 0, dp(2)); return t;
    }

    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
            return;
        }
        ensureSessionAndResume();
    }

    private void ensureSessionAndResume() {
        if (session == null) {
            try {
                ArCoreApk.InstallStatus statusInstall = ArCoreApk.getInstance().requestInstall(this, !installRequested);
                if (statusInstall == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                    installRequested = true;
                    setStatus("Google Play Services for AR در حال نصب/به‌روزرسانی است…", false);
                    return;
                }
                session = new Session(this);
                Config config = session.getConfig();
                depthSupported = session.isDepthModeSupported(Config.DepthMode.AUTOMATIC);
                if (!depthSupported) {
                    setStatus("این گوشی ARCore Depth API را پشتیبانی نمی‌کند؛ اسکن واقعی ساخته نمی‌شود.", true);
                    scanButton.setEnabled(false);
                    badge.setText("DEPTH UNSUPPORTED • NO FAKE 3D");
                    return;
                }
                config.setDepthMode(Config.DepthMode.AUTOMATIC);
                config.setUpdateMode(Config.UpdateMode.LATEST_CAMERA_IMAGE);
                session.configure(config);
                badge.setText("ARCORE DEPTH • METRIC CAPTURE");
                setStatus("Depth API آماده است • صورت را داخل بیضی نگه دارید", false);
                scanButton.setEnabled(true);
            } catch (UnavailableArcoreNotInstalledException | UnavailableUserDeclinedInstallationException e) {
                setStatus("ARCore نصب نیست یا نصب آن رد شده است.", true);
                return;
            } catch (UnavailableApkTooOldException e) {
                setStatus("Google Play Services for AR باید به‌روزرسانی شود.", true); return;
            } catch (UnavailableSdkTooOldException e) {
                setStatus("نسخه ARCore برنامه نیاز به به‌روزرسانی دارد.", true); return;
            } catch (UnavailableDeviceNotCompatibleException e) {
                setStatus("این دستگاه با ARCore سازگار نیست.", true); return;
            } catch (Exception e) {
                setStatus("راه‌اندازی اسکنر عمق انجام نشد: " + e.getClass().getSimpleName(), true); return;
            }
        }
        if (session != null && depthSupported) {
            try { session.resume(); } catch (CameraNotAvailableException e) { setStatus("دوربین در دسترس نیست.", true); }
            glView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (glView != null) glView.onPause();
        if (session != null) session.pause();
    }

    @Override
    protected void onDestroy() {
        if (session != null) { session.close(); session = null; }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) ensureSessionAndResume();
            else finishWithFailure("camera-permission-denied", "مجوز دوربین برای اسکن عمق لازم است");
        }
    }

    private void beginScan() {
        if (!depthSupported || session == null || scanning) return;
        synchronized (rawPoints) { rawPoints.clear(); }
        scanning = true; finishing = false; depthFrames = 0; skippedDepthFrames = 0; renderedFrames = 0;
        initialPose = null; maxCameraTravelM = 0f; firstValidDepthAt = 0L; scanStartedAt = SystemClock.elapsedRealtime();
        progress.setProgress(0);
        scanButton.setText("پایان و ساخت مدل عمقی");
        badge.setText("SCANNING • REAL DEPTH");
        setStatus("۱–۲ ثانیه کالیبراسیون؛ سپس آرام حدود ۱۵–۲۵ سانتی‌متر چپ → روبه‌رو → راست حرکت کنید • سر ثابت", false);
    }

    private void setStatus(String s, boolean error) {
        runOnUiThread(() -> {
            status.setText(s);
            status.setTextColor(error ? Color.rgb(255, 110, 126) : Color.WHITE);
        });
    }

    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig config) {
        GLES20.glClearColor(0.01f, 0.035f, 0.045f, 1f);
        cameraTextureId = createExternalTexture();
        setupBackgroundProgram();
        quadPos = floatBuffer(quadCoords);
        quadUv = floatBuffer(new float[]{0,1, 1,1, 0,0, 1,0});
    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        if (session != null) session.setDisplayGeometry(displayRotation(), width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl10) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Session s = session;
        if (s == null || cameraTextureId < 0) return;
        try {
            s.setDisplayGeometry(displayRotation(), Math.max(1, glView.getWidth()), Math.max(1, glView.getHeight()));
            s.setCameraTextureName(cameraTextureId);
            Frame frame = s.update();
            drawCameraBackground(frame);
            Camera camera = frame.getCamera();
            if (camera.getTrackingState() != TrackingState.TRACKING) {
                maybeUpdateUi("ردیابی AR متوقف است؛ گوشی را آرام حرکت دهید", 0);
                return;
            }
            if (scanning) {
                renderedFrames++;
                if (initialPose == null) initialPose = camera.getPose();
                updateTravel(camera.getPose());
                long elapsed = SystemClock.elapsedRealtime() - scanStartedAt;
                if (elapsed >= DEPTH_WARMUP_MS) {
                    captureDepthFrame(frame, camera);
                }
                int pct = (int)Math.min(1000, elapsed * 1000L / TARGET_SCAN_MS);
                String phase = elapsed < DEPTH_WARMUP_MS ? "کالیبراسیون Depth… گوشی را کمی حرکت دهید" :
                        String.format(Locale.US, "Depth frames: %d • points: %d • حرکت: %.0f mm", depthFrames, pointCount(), maxCameraTravelM * 1000f);
                maybeUpdateUi(phase, pct);
                boolean enough = depthFrames >= 8 && pointCount() >= 500;
                if (elapsed >= TARGET_SCAN_MS && enough && !finishing) {
                    runOnUiThread(() -> finishScan(true));
                } else if (elapsed >= MAX_SCAN_MS && !finishing) {
                    runOnUiThread(() -> finishScan(true));
                }
            }
        } catch (CameraNotAvailableException e) {
            setStatus("دوربین ARCore در دسترس نیست", true);
        } catch (Throwable t) {
            if (scanning) skippedDepthFrames++;
        }
    }

    private void maybeUpdateUi(String message, int pct) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastUiUpdate < 240) return;
        lastUiUpdate = now;
        runOnUiThread(() -> { status.setText(message); progress.setProgress(pct); });
    }

    private int pointCount() { synchronized (rawPoints) { return rawPoints.size(); } }

    private void updateTravel(Pose pose) {
        if (initialPose == null) return;
        float[] a = initialPose.getTranslation(), b = pose.getTranslation();
        float dx=a[0]-b[0], dy=a[1]-b[1], dz=a[2]-b[2];
        maxCameraTravelM = Math.max(maxCameraTravelM, (float)Math.sqrt(dx*dx+dy*dy+dz*dz));
    }

    private void captureDepthFrame(Frame frame, Camera camera) {
        Image depth = null;
        try {
            depth = frame.acquireDepthImage16Bits();
            int w = depth.getWidth(), h = depth.getHeight();
            if (w < 16 || h < 16) return;
            Image.Plane plane = depth.getPlanes()[0];
            ByteBuffer bb = plane.getBuffer().duplicate().order(ByteOrder.LITTLE_ENDIAN);
            int rowStride = plane.getRowStride(), pixelStride = plane.getPixelStride();

            int centerMm = estimateCenterDepth(bb, rowStride, pixelStride, w, h);
            if (centerMm < 250 || centerMm > 1800) { skippedDepthFrames++; return; }

            // Depth image pixels align with the CPU camera image geometry; use image intrinsics.
            CameraIntrinsics intr = camera.getImageIntrinsics();
            float[] focal = intr.getFocalLength();
            float[] principal = intr.getPrincipalPoint();
            int[] dims = intr.getImageDimensions();
            float sx = w / (float)Math.max(1, dims[0]);
            float sy = h / (float)Math.max(1, dims[1]);
            float fx = focal[0] * sx, fy = focal[1] * sy;
            float cx = principal[0] * sx, cy = principal[1] * sy;
            if (fx < 1 || fy < 1) return;

            Pose camPose = camera.getPose();
            Pose invInitial = initialPose == null ? Pose.IDENTITY : initialPose.inverse();
            final int stride = (w >= 480 ? 6 : (w >= 300 ? 5 : 4));
            ArrayList<float[]> framePoints = new ArrayList<>();
            for (int y = stride; y < h - stride; y += stride) {
                float ny = (y - h * .50f) / (h * .46f);
                for (int x = stride; x < w - stride; x += stride) {
                    float nx = (x - w * .50f) / (w * .36f);
                    if (nx*nx + ny*ny > 1.0f) continue; // face-shaped ROI
                    int mm = readDepthMm(bb, rowStride, pixelStride, x, y);
                    if (mm <= 0 || mm < 250 || mm > 2000) continue;
                    if (Math.abs(mm - centerMm) > 400) continue; // suppress distant background, tolerate face/shoulder depth spread
                    float z = mm / 1000f;
                    float camX = (x - cx) / fx * z;
                    float camY = -(y - cy) / fy * z;
                    float[] world = camPose.transformPoint(new float[]{camX, camY, -z});
                    float[] local = invInitial.transformPoint(world);
                    framePoints.add(local);
                }
            }
            if (framePoints.size() >= 8) {
                synchronized (rawPoints) {
                    if (rawPoints.size() < 180_000) rawPoints.addAll(framePoints);
                }
                depthFrames++;
                if (firstValidDepthAt == 0L) firstValidDepthAt = SystemClock.elapsedRealtime();
            }
        } catch (NotYetAvailableException e) {
            skippedDepthFrames++;
        } catch (Throwable t) {
            skippedDepthFrames++;
        } finally {
            if (depth != null) depth.close();
        }
    }

    private int estimateCenterDepth(ByteBuffer bb, int rowStride, int pixelStride, int w, int h) {
        int[] vals = new int[64]; int n = 0;
        for (int gy=-3; gy<=3; gy++) for (int gx=-3; gx<=3; gx++) {
            int x = Math.max(0, Math.min(w-1, Math.round(w*.5f + gx*w*.035f)));
            int y = Math.max(0, Math.min(h-1, Math.round(h*.5f + gy*h*.035f)));
            int d = readDepthMm(bb,rowStride,pixelStride,x,y);
            if (d >= 250 && d <= 1800 && n < vals.length) vals[n++] = d;
        }
        if (n == 0) return 0;
        java.util.Arrays.sort(vals,0,n);
        return vals[n/2];
    }

    private int readDepthMm(ByteBuffer bb, int rowStride, int pixelStride, int x, int y) {
        int index = y * rowStride + x * pixelStride;
        if (index < 0 || index + 1 >= bb.limit()) return 0;
        return bb.getShort(index) & 0xFFFF;
    }

    private void finishScan(boolean automatic) {
        if (!scanning || finishing) return;
        finishing = true; scanning = false;
        scanButton.setEnabled(false);
        scanButton.setText("در حال ساخت Point Cloud…");
        badge.setText("PROCESSING • METRIC DEPTH");
        setStatus("پاک‌سازی نویز و هم‌ترازسازی نمونه‌های عمق…", false);
        new Thread(() -> {
            try {
                JSONObject result = buildResultJson(automatic);
                ClinicalScanStore.putResult(result.toString());
                runOnUiThread(() -> { setResult(RESULT_OK); finish(); });
            } catch (Throwable t) {
                runOnUiThread(() -> finishWithFailure("processing-failed", "پردازش اسکن انجام نشد"));
            }
        }).start();
    }

    private JSONObject buildResultJson(boolean automatic) throws Exception {
        ArrayList<float[]> copy;
        synchronized (rawPoints) { copy = new ArrayList<>(rawPoints); }
        LinkedHashMap<Long,float[]> voxels = new LinkedHashMap<>();
        final float voxel = .0045f; // 4.5 mm research downsample
        for (float[] p : copy) {
            int qx=Math.round(p[0]/voxel), qy=Math.round(p[1]/voxel), qz=Math.round(p[2]/voxel);
            long key=((long)(qx & 0x1FFFFF)<<42)|((long)(qy & 0x1FFFFF)<<21)|(long)(qz & 0x1FFFFF);
            if (!voxels.containsKey(key)) voxels.put(key,p);
        }
        List<float[]> unique = new ArrayList<>(voxels.values());
        if (unique.isEmpty()) return failureJson("insufficient-depth", String.format(Locale.US, "داده عمق کافی ثبت نشد • Depth frames: %d • skipped: %d • حرکت: %.0f mm. نور را بیشتر کنید، فاصله را حدود ۵۰–۹۰ سانتی‌متر نگه دارید و گوشی را آرام ۱۵–۲۵ سانتی‌متر حرکت دهید.", depthFrames, skippedDepthFrames, maxCameraTravelM*1000f));

        int step = Math.max(1, (int)Math.ceil(unique.size()/(double)MAX_RETURN_POINTS));
        ArrayList<float[]> sampled = new ArrayList<>();
        for (int i=0;i<unique.size() && sampled.size()<MAX_RETURN_POINTS;i+=step) sampled.add(unique.get(i));

        // Robust center (simple mean after near-center crop) and bounds.
        float cx=0,cy=0,cz=0; int cn=0;
        for(float[] p:sampled){ if(Math.abs(p[0])<.45f && Math.abs(p[1])<.55f && p[2]>-1.8f && p[2]<.4f){cx+=p[0];cy+=p[1];cz+=p[2];cn++;} }
        if(cn>0){cx/=cn;cy/=cn;cz/=cn;}
        float minX=Float.MAX_VALUE,minY=Float.MAX_VALUE,minZ=Float.MAX_VALUE,maxX=-Float.MAX_VALUE,maxY=-Float.MAX_VALUE,maxZ=-Float.MAX_VALUE;
        JSONArray pts = new JSONArray();
        for(float[] p:sampled){
            int x=Math.round((p[0]-cx)*1000f), y=Math.round((p[1]-cy)*1000f), z=Math.round((p[2]-cz)*1000f);
            // Keep a clinically useful near-face volume; reject implausible far outliers.
            if(Math.abs(x)>600 || Math.abs(y)>700 || Math.abs(z)>500) continue;
            JSONArray a=new JSONArray();a.put(x);a.put(y);a.put(z);pts.put(a);
            minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);minZ=Math.min(minZ,z);maxZ=Math.max(maxZ,z);
        }
        int n=pts.length();
        boolean pass=depthFrames>=8 && n>=1200 && maxCameraTravelM>=.05f;
        JSONObject out=new JSONObject();
        out.put("ok", n>=300);
        out.put("mode","ARCORE_DEPTH_POINT_CLOUD");
        out.put("metricDepth",true);
        out.put("unit","mm");
        out.put("points",pts);
        out.put("pointCount",n);
        out.put("depthFrames",depthFrames);
        out.put("skippedDepthFrames",skippedDepthFrames);
        out.put("cameraTravelMm",Math.round(maxCameraTravelM*1000f));
        out.put("durationMs",SystemClock.elapsedRealtime()-scanStartedAt);
        out.put("autoFinished",automatic);
        out.put("qc",pass?"PASS":"REVIEW");
        JSONObject bounds=new JSONObject();
        if(n>0){bounds.put("widthMm",Math.round(maxX-minX));bounds.put("heightMm",Math.round(maxY-minY));bounds.put("depthMm",Math.round(maxZ-minZ));}
        out.put("captureBounds",bounds);
        out.put("validatedMedicalDevice",false);
        out.put("label","Clinical 3D Visualization • Research Mode");
        out.put("note","Metric depth is captured from ARCore Depth API. Not validated for diagnosis, dosing, injection depth, or treatment decisions.");
        return out;
    }

    private JSONObject failureJson(String reason, String message) throws Exception {
        JSONObject o=new JSONObject();o.put("ok",false);o.put("reason",reason);o.put("message",message);return o;
    }

    private void finishWithFailure(String reason, String message) {
        try { ClinicalScanStore.putResult(failureJson(reason,message).toString()); } catch (Exception ignored) {}
        setResult(RESULT_CANCELED); finish();
    }

    private int displayRotation() {
        int r = getWindowManager().getDefaultDisplay().getRotation();
        if (r == Surface.ROTATION_90) return Surface.ROTATION_90;
        if (r == Surface.ROTATION_180) return Surface.ROTATION_180;
        if (r == Surface.ROTATION_270) return Surface.ROTATION_270;
        return Surface.ROTATION_0;
    }

    private int createExternalTexture() {
        int[] t=new int[1];GLES20.glGenTextures(1,t,0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,t[0]);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
        return t[0];
    }

    private void setupBackgroundProgram() {
        String vs="attribute vec2 aPos;attribute vec2 aUv;varying vec2 vUv;void main(){gl_Position=vec4(aPos,0.0,1.0);vUv=aUv;}";
        String fs="#extension GL_OES_EGL_image_external : require\nprecision mediump float;varying vec2 vUv;uniform samplerExternalOES uTex;void main(){gl_FragColor=texture2D(uTex,vUv);}";
        int v=compileShader(GLES20.GL_VERTEX_SHADER,vs), f=compileShader(GLES20.GL_FRAGMENT_SHADER,fs);
        bgProgram=GLES20.glCreateProgram();GLES20.glAttachShader(bgProgram,v);GLES20.glAttachShader(bgProgram,f);GLES20.glLinkProgram(bgProgram);
        bgPos=GLES20.glGetAttribLocation(bgProgram,"aPos");bgUv=GLES20.glGetAttribLocation(bgProgram,"aUv");bgSampler=GLES20.glGetUniformLocation(bgProgram,"uTex");
    }

    private int compileShader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}

    private void drawCameraBackground(Frame frame) {
        try {
            frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES, quadCoords, Coordinates2d.TEXTURE_NORMALIZED, uvCoords);
            quadUv.position(0);quadUv.put(uvCoords);quadUv.position(0);
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glUseProgram(bgProgram);
            quadPos.position(0);GLES20.glEnableVertexAttribArray(bgPos);GLES20.glVertexAttribPointer(bgPos,2,GLES20.GL_FLOAT,false,0,quadPos);
            quadUv.position(0);GLES20.glEnableVertexAttribArray(bgUv);GLES20.glVertexAttribPointer(bgUv,2,GLES20.GL_FLOAT,false,0,quadUv);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,cameraTextureId);GLES20.glUniform1i(bgSampler,0);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);
            GLES20.glDisableVertexAttribArray(bgPos);GLES20.glDisableVertexAttribArray(bgUv);
        } catch (Throwable ignored) {}
    }

    private FloatBuffer floatBuffer(float[] a){ByteBuffer b=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder());FloatBuffer f=b.asFloatBuffer();f.put(a);f.position(0);return f;}
}
