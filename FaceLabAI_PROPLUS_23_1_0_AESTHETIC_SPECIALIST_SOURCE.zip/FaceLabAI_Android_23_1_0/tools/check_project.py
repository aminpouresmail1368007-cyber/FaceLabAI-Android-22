from pathlib import Path
import re, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
required=['home','sim','academy','cases','progress','profile','regionbar','stage','faceImg','dynamicMap','faceMapBadge','zones','effects','targetPoint','faceLift','syringe','resFluid','barrelFluid','beforeImg','afterImg','compareSlider','face3DCanvas','clinical3DCanvas','threeDPanel','threeDAngle','academyList','academySummary','caseGrid','galleryInput','lessonModal','lessonQuiz','searchModal','searchResults','caseModal','aboutModal','securityStatus']
missing=[x for x in required if f'id="{x}"' not in html]
if missing: raise SystemExit('Missing DOM id(s): '+', '.join(missing))
for token in ['FACE LAB PRO+ 23.1.0','AESTHETIC SPECIALIST ACADEMY','window.FaceLabNativePhoto','window.FaceLabFaceMap','window.FaceLabClinicalScanResult','injectNow','openCamera','openSearch','showAbout','Specialist Aesthetic Academy','RECONSTRUCTED 3D','ARCORE DEPTH','Security & License Readiness']:
    if token not in html: raise SystemExit('Missing feature token: '+token)
handlers=set(re.findall(r'onclick="([A-Za-z_$][A-Za-z0-9_$]*)\(',html))
handlers |= set(re.findall(r'oninput="([A-Za-z_$][A-Za-z0-9_$]*)\(',html))
handlers |= set(re.findall(r'onchange="([A-Za-z_$][A-Za-z0-9_$]*)\(',html))
defs=set(re.findall(r'function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(',html))
missing_handlers=sorted(h for h in handlers if h not in defs and h not in {'if'})
if missing_handlers: raise SystemExit('Missing JS handler(s): '+', '.join(missing_handlers))
print('FACE LAB PRO+ 23.1.0 specialist project check: OK')
