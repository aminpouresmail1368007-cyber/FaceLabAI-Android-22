# FACE LAB PRO+ 23.0.2 — Clinical 3D Scan (Research Visualization)

Version 23.0.2 adds an optional **ARCore Depth** capture path for devices that support the Depth API.

## What is new
- Native guided 10-second depth scan using the rear camera.
- ARCore Depth API is checked at runtime. Unsupported devices do **not** receive a fake “real scan”.
- Metric depth samples are accumulated across camera motion into a common AR coordinate system.
- Near-face depth filtering, background rejection, voxel downsampling, and a QC summary.
- A rotatable WebGL metric point-cloud viewer inside FACE LAB.
- Scan QC fields include depth-frame count, point count, and camera sweep.
- Existing single-photo Face Lock and reconstructed 3D mode remain available.

## Important scope
This build is a **research / educational visualization tool**. ARCore depth is metric device-derived depth, but this application has not been validated against a reference 3D scanner and is not a medical device. Do not use it for diagnosis, treatment decisions, medication dosing, injection depth, procedural coordinates, or other clinical measurements until a formal validation study is completed.

## Capture workflow
1. Open Simulator.
2. Tap `CLINICAL 3D SCAN`.
3. Use the rear camera and keep the face inside the oval.
4. Keep the subject still while the operator moves the phone slowly left → front → right for ~10 seconds.
5. The app builds a metric depth point cloud when enough depth data is available.
6. Rotate and zoom the scan in the 3D viewer.

## Device requirements
- Android 10+ (minSdk 29 in this project).
- ARCore / Google Play Services for AR.
- ARCore Depth API support for the real depth mode.
- Camera permission.

## Build
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.10.2
- compileSdk / targetSdk 35
- `com.google.ar:core:1.51.0`
- ML Kit Face Detection 16.1.7

Build command:

```bash
gradle :app:assembleDebug --no-daemon
```


## 23.0.2 Depth capture reliability fix
- Adds a short ARCore depth warm-up before counting samples.
- Captures depth every tracked frame during the scan.
- Uses camera **image intrinsics** for CPU depth-image projection.
- Widens near-face depth acceptance to tolerate device-to-device ARCore depth behavior.
- Extends capture up to 18 seconds only when valid depth is still sparse.
- Reports diagnostic frame / skipped-frame / camera-travel values when capture is insufficient.
- Remains research visualization only; not a validated medical measurement.
