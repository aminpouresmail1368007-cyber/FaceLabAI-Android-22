package com.facelab.ai;

import android.app.Activity;
import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.PointF;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.security.MessageDigest;
import java.util.List;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.common.PointF3D;
import com.google.mlkit.vision.common.Triangle;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceContour;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.FaceLandmark;
import com.google.mlkit.vision.facemesh.FaceMesh;
import com.google.mlkit.vision.facemesh.FaceMeshDetection;
import com.google.mlkit.vision.facemesh.FaceMeshDetector;
import com.google.mlkit.vision.facemesh.FaceMeshDetectorOptions;
import com.google.mlkit.vision.facemesh.FaceMeshPoint;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private static final int NATIVE_CAMERA_REQUEST = 7102;
    private static final int CLINICAL_SCAN_REQUEST = 7103;
    private static final int CAMERA_PERMISSION_REQUEST = 7104;
    private static final String CAPTURE_PREFS = "facelab_capture";
    private static final String PREF_PENDING_CAMERA_URI = "pending_camera_uri";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private boolean pendingNativeCamera = false;
    private boolean webReady = false;
    private volatile String queuedNativePhotoDataUrl = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 9, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 9, 12));

        webView = new WebView(this);
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep FACE LAB's
        // bottom navigation above the system navigation/gesture area.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottomInset);
            return insets;
        });
        setContentView(webView);
        configureWebView();
        restorePendingCameraUri(savedInstanceState);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(false);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.rgb(5, 9, 12));
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u == null ? "" : u.getScheme();
                return scheme != null && !scheme.equals("file") && !scheme.equals("about");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                webReady = true;
                deliverQueuedNativePhoto();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent gallery = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");

                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cameraOutputUri = createCameraOutputUri();
                if (cameraOutputUri != null) {
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
                    grantCameraUriPermissions(camera, cameraOutputUri);
                }
                if (params != null && params.isCaptureEnabled()) {
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                }

                try {
                    if (params != null && params.isCaptureEnabled() && cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(camera, FILE_CHOOSER_REQUEST);
                        return true;
                    }
                    Intent chooser = new Intent(Intent.ACTION_CHOOSER);
                    chooser.putExtra(Intent.EXTRA_INTENT, gallery);
                    chooser.putExtra(Intent.EXTRA_TITLE, "عکس گرفتن یا انتخاب از گالری");
                    if (cameraOutputUri != null && camera.resolveActivity(getPackageManager()) != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "گالری یا دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private SharedPreferences capturePrefs() {
        return getSharedPreferences(CAPTURE_PREFS, MODE_PRIVATE);
    }

    private void rememberPendingCameraUri(Uri uri) {
        if (uri == null) return;
        capturePrefs().edit().putString(PREF_PENDING_CAMERA_URI, uri.toString()).apply();
    }

    private void restorePendingCameraUri(Bundle state) {
        String value = null;
        if (state != null) value = state.getString(PREF_PENDING_CAMERA_URI, null);
        if (value == null || value.isEmpty()) value = capturePrefs().getString(PREF_PENDING_CAMERA_URI, null);
        if (value != null && !value.isEmpty()) {
            try { cameraOutputUri = Uri.parse(value); } catch (Exception ignored) { cameraOutputUri = null; }
        }
    }

    private void clearPendingCameraUri() {
        capturePrefs().edit().remove(PREF_PENDING_CAMERA_URI).apply();
    }

    private Uri createCameraOutputUri() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "FaceLab_Camera_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri != null) rememberPendingCameraUri(uri);
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    private void grantCameraUriPermissions(Intent camera, Uri uri) {
        if (camera == null || uri == null) return;
        int flags = Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION;
        camera.addFlags(flags);
        camera.setClipData(android.content.ClipData.newRawUri("FACE LAB capture", uri));
        try {
            List<ResolveInfo> handlers = getPackageManager().queryIntentActivities(camera, PackageManager.MATCH_DEFAULT_ONLY);
            for (ResolveInfo info : handlers) {
                if (info != null && info.activityInfo != null) {
                    try { grantUriPermission(info.activityInfo.packageName, uri, flags); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    private boolean uriHasImageBytes(Uri uri) {
        if (uri == null) return false;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            byte[] buffer = new byte[2048];
            int total = 0, n;
            while (total < 4096 && (n = in.read(buffer)) > 0) total += n;
            return total >= 512;
        } catch (Exception e) {
            return false;
        }
    }

    private void cleanupCameraUri(Uri uri, boolean deleteRow) {
        if (uri != null && deleteRow) {
            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
        }
        if (cameraOutputUri != null && uri != null && cameraOutputUri.equals(uri)) cameraOutputUri = null;
        clearPendingCameraUri();
    }

    private void processNativeCameraResult(final Uri uri, final int resultCode) {
        if (uri == null) {
            Toast.makeText(this, "عکس دوربین دریافت نشد", Toast.LENGTH_LONG).show();
            clearPendingCameraUri();
            return;
        }
        new Thread(() -> {
            boolean ready = false;
            for (int attempt = 0; attempt < 12; attempt++) {
                if (uriHasImageBytes(uri)) { ready = true; break; }
                try { Thread.sleep(140L + attempt * 25L); } catch (InterruptedException ignored) { break; }
            }
            if (!ready) {
                runOnUiThread(() -> {
                    cleanupCameraUri(uri, true);
                    Toast.makeText(MainActivity.this, "عکس ثبت شد اما فایل تصویر کامل تحویل برنامه نشد؛ دوباره امتحان کن", Toast.LENGTH_LONG).show();
                });
                return;
            }
            try {
                String dataUrl = optimizedDataUrlFromUri(uri, 1200, 84);
                queuedNativePhotoDataUrl = dataUrl;
                runOnUiThread(() -> {
                    cleanupCameraUri(uri, false);
                    deliverQueuedNativePhoto();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    cleanupCameraUri(uri, false);
                    Toast.makeText(MainActivity.this, "خواندن عکس دوربین انجام نشد", Toast.LENGTH_LONG).show();
                });
            }
        }, "FaceLabPhotoImport").start();
    }

    private void deliverQueuedNativePhoto() {
        final String dataUrl = queuedNativePhotoDataUrl;
        if (!webReady || webView == null || dataUrl == null || dataUrl.isEmpty()) return;
        final String js = "(function(){if(typeof window.FaceLabNativePhoto==='function'){window.FaceLabNativePhoto(" + JSONObject.quote(dataUrl) + ");return 'accepted';}return 'wait';})()";
        webView.evaluateJavascript(js, value -> {
            if (value != null && value.contains("accepted")) {
                queuedNativePhotoDataUrl = null;
            } else if (webView != null) {
                webView.postDelayed(this::deliverQueuedNativePhoto, 220);
            }
        });
    }

    private String optimizedDataUrlFromUri(Uri uri, int maxSide, int jpegQuality) throws Exception {
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        Bitmap bitmap = ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            int w = Math.max(1, info.getSize().getWidth());
            int h = Math.max(1, info.getSize().getHeight());
            int longest = Math.max(w, h);
            if (longest > maxSide) {
                float scale = (float) maxSide / (float) longest;
                decoder.setTargetSize(Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)));
            }
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, Math.max(70, Math.min(95, jpegQuality)), bos);
        if (!bitmap.isRecycled()) bitmap.recycle();
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    private void launchFrontCameraInternal() {
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraOutputUri = createCameraOutputUri();
            if (cameraOutputUri == null) {
                Toast.makeText(this, "امکان ساخت فایل عکس وجود ندارد", Toast.LENGTH_LONG).show();
                return;
            }
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            camera.putExtra("return-data", false);
            camera.putExtra("android.intent.extras.CAMERA_FACING", 1);
            camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
            grantCameraUriPermissions(camera, cameraOutputUri);

            if (camera.resolveActivity(getPackageManager()) != null) {
                rememberPendingCameraUri(cameraOutputUri);
                startActivityForResult(camera, NATIVE_CAMERA_REQUEST);
            } else {
                cleanupCameraUri(cameraOutputUri, true);
                Toast.makeText(this, "برنامه دوربین در دسترس نیست", Toast.LENGTH_LONG).show();
            }
        } catch (SecurityException e) {
            cleanupCameraUri(cameraOutputUri, true);
            Toast.makeText(this, "مجوز دوربین لازم است", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            cleanupCameraUri(cameraOutputUri, true);
            Toast.makeText(this, "باز کردن دوربین انجام نشد", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean openCamera = pendingNativeCamera;
            pendingNativeCamera = false;
            if (granted && openCamera) {
                launchFrontCameraInternal();
            } else if (!granted && openCamera) {
                Toast.makeText(this, "برای گرفتن عکس، دسترسی دوربین را فعال کنید", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CLINICAL_SCAN_REQUEST) {
            String result = ClinicalScanStore.takeResult();
            if (result == null || result.isEmpty()) result = "{\"ok\":false,\"reason\":\"cancelled\"}";
            final String payload = result;
            if (webView != null) webView.evaluateJavascript(
                    "window.FaceLabClinicalScanResult && window.FaceLabClinicalScanResult(" + JSONObject.quote(payload) + ")", null);
            return;
        }
        if (requestCode == NATIVE_CAMERA_REQUEST) {
            Uri captureUri = cameraOutputUri;
            if (captureUri == null) {
                String saved = capturePrefs().getString(PREF_PENDING_CAMERA_URI, null);
                if (saved != null && !saved.isEmpty()) {
                    try { captureUri = Uri.parse(saved); } catch (Exception ignored) {}
                }
            }
            processNativeCameraResult(captureUri, resultCode);
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
                if (cameraOutputUri != null) {
                    try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
                }
            } else if (cameraOutputUri != null) {
                result = new Uri[]{cameraOutputUri};
            }
        } else if (cameraOutputUri != null) {
            try { getContentResolver().delete(cameraOutputUri, null, null); } catch (Exception ignored) {}
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
        cameraOutputUri = null;
        clearPendingCameraUri();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (cameraOutputUri != null) outState.putString(PREF_PENDING_CAMERA_URI, cameraOutputUri.toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.FaceLab && FaceLab.handleAndroidBack ? FaceLab.handleAndroidBack() : 'not-handled'", value -> {
                if ("\"handled\"".equals(value)) return;
                if (webView.canGoBack()) webView.goBack();
                else MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public String getVersion() { return "23.2.1"; }



        @JavascriptInterface
        public void detectFace(final String dataUrl) {
            if (dataUrl == null || !dataUrl.contains(",")) {
                sendFaceMapFailure("invalid-image");
                return;
            }
            new Thread(() -> {
                try {
                    String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) { sendFaceMapFailure("decode-failed"); return; }
                    final int iw = bitmap.getWidth(), ih = bitmap.getHeight();
                    InputImage image = InputImage.fromBitmap(bitmap, 0);
                    FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                            .build();
                    FaceDetector detector = FaceDetection.getClient(options);
                    detector.process(image)
                            .addOnSuccessListener(faces -> {
                                try {
                                    if (faces == null || faces.isEmpty()) { sendFaceMapFailure("no-face"); return; }
                                    Face best = faces.get(0);
                                    int bestArea = best.getBoundingBox().width() * best.getBoundingBox().height();
                                    for (Face f : faces) {
                                        int a = f.getBoundingBox().width() * f.getBoundingBox().height();
                                        if (a > bestArea) { best = f; bestArea = a; }
                                    }
                                    JSONObject out = new JSONObject();
                                    out.put("ok", true);
                                    out.put("width", iw); out.put("height", ih);
                                    Rect r = best.getBoundingBox();
                                    JSONObject box = new JSONObject();
                                    box.put("left", clamp01((double) r.left / iw));
                                    box.put("top", clamp01((double) r.top / ih));
                                    box.put("right", clamp01((double) r.right / iw));
                                    box.put("bottom", clamp01((double) r.bottom / ih));
                                    out.put("box", box);
                                    JSONArray points = new JSONArray();
                                    int[] lmTypes = new int[]{
                                            FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE,
                                            FaceLandmark.NOSE_BASE, FaceLandmark.MOUTH_LEFT,
                                            FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM,
                                            FaceLandmark.LEFT_EAR, FaceLandmark.RIGHT_EAR,
                                            FaceLandmark.LEFT_CHEEK, FaceLandmark.RIGHT_CHEEK
                                    };
                                    for (int t : lmTypes) {
                                        FaceLandmark lm = best.getLandmark(t);
                                        if (lm != null) points.put(normPoint(lm.getPosition(), iw, ih));
                                    }
                                    out.put("points", points);
                                    JSONArray contours = new JSONArray();
                                    JSONObject namedContours = new JSONObject();
                                    int[] ct = new int[]{
                                            FaceContour.FACE, FaceContour.LEFT_EYEBROW_TOP, FaceContour.RIGHT_EYEBROW_TOP,
                                            FaceContour.LEFT_EYE, FaceContour.RIGHT_EYE, FaceContour.NOSE_BRIDGE,
                                            FaceContour.NOSE_BOTTOM, FaceContour.UPPER_LIP_TOP, FaceContour.LOWER_LIP_BOTTOM
                                    };
                                    String[] ctNames = new String[]{
                                            "face", "leftEyebrowTop", "rightEyebrowTop",
                                            "leftEye", "rightEye", "noseBridge",
                                            "noseBottom", "upperLipTop", "lowerLipBottom"
                                    };
                                    for (int i = 0; i < ct.length; i++) {
                                        int t = ct[i];
                                        FaceContour fc = best.getContour(t);
                                        if (fc == null || fc.getPoints() == null || fc.getPoints().isEmpty()) continue;
                                        JSONArray arr = new JSONArray();
                                        for (PointF pt : fc.getPoints()) arr.put(normPoint(pt, iw, ih));
                                        contours.put(arr);
                                        namedContours.put(ctNames[i], arr);
                                    }
                                    out.put("contours", contours);
                                    out.put("namedContours", namedContours);

                                    // Dense visual points: use ML Kit contour points plus interpolated points
                                    // so the green overlay follows the user's photographed face more closely.
                                    JSONArray densePoints = new JSONArray();
                                    for (int t : ct) {
                                        FaceContour fc = best.getContour(t);
                                        if (fc == null || fc.getPoints() == null || fc.getPoints().isEmpty()) continue;
                                        List<PointF> cps = fc.getPoints();
                                        for (int i = 0; i < cps.size(); i++) {
                                            PointF a = cps.get(i);
                                            densePoints.put(normPoint(a, iw, ih));
                                            if (i + 1 < cps.size()) {
                                                PointF bpt = cps.get(i + 1);
                                                densePoints.put(normPoint(new PointF((2f * a.x + bpt.x) / 3f, (2f * a.y + bpt.y) / 3f), iw, ih));
                                                densePoints.put(normPoint(new PointF((a.x + 2f * bpt.x) / 3f, (a.y + 2f * bpt.y) / 3f), iw, ih));
                                            }
                                        }
                                    }
                                    out.put("densePoints", densePoints);

                                    // Named anchors are used by the personalized 3D face renderer.
                                    JSONObject anchors = new JSONObject();
                                    FaceLandmark leftEye = best.getLandmark(FaceLandmark.LEFT_EYE);
                                    FaceLandmark rightEye = best.getLandmark(FaceLandmark.RIGHT_EYE);
                                    FaceLandmark nose = best.getLandmark(FaceLandmark.NOSE_BASE);
                                    FaceLandmark mouthLeft = best.getLandmark(FaceLandmark.MOUTH_LEFT);
                                    FaceLandmark mouthRight = best.getLandmark(FaceLandmark.MOUTH_RIGHT);
                                    FaceLandmark mouthBottom = best.getLandmark(FaceLandmark.MOUTH_BOTTOM);
                                    FaceLandmark leftCheek = best.getLandmark(FaceLandmark.LEFT_CHEEK);
                                    FaceLandmark rightCheek = best.getLandmark(FaceLandmark.RIGHT_CHEEK);
                                    FaceLandmark leftEar = best.getLandmark(FaceLandmark.LEFT_EAR);
                                    FaceLandmark rightEar = best.getLandmark(FaceLandmark.RIGHT_EAR);
                                    if (leftEye != null) anchors.put("leftEye", normPoint(leftEye.getPosition(), iw, ih));
                                    if (rightEye != null) anchors.put("rightEye", normPoint(rightEye.getPosition(), iw, ih));
                                    if (nose != null) anchors.put("nose", normPoint(nose.getPosition(), iw, ih));
                                    if (mouthLeft != null) anchors.put("mouthLeft", normPoint(mouthLeft.getPosition(), iw, ih));
                                    if (mouthRight != null) anchors.put("mouthRight", normPoint(mouthRight.getPosition(), iw, ih));
                                    if (mouthBottom != null) anchors.put("mouthBottom", normPoint(mouthBottom.getPosition(), iw, ih));
                                    if (leftCheek != null) anchors.put("leftCheek", normPoint(leftCheek.getPosition(), iw, ih));
                                    if (rightCheek != null) anchors.put("rightCheek", normPoint(rightCheek.getPosition(), iw, ih));
                                    if (leftEar != null) anchors.put("leftEar", normPoint(leftEar.getPosition(), iw, ih));
                                    if (rightEar != null) anchors.put("rightEar", normPoint(rightEar.getPosition(), iw, ih));
                                    if (mouthLeft != null && mouthRight != null && mouthBottom != null) {
                                        PointF lp = mouthLeft.getPosition(), rp = mouthRight.getPosition(), bp = mouthBottom.getPosition();
                                        anchors.put("lips", normPoint(new PointF((lp.x + rp.x + bp.x) / 3f, (lp.y + rp.y + bp.y) / 3f), iw, ih));
                                    } else if (mouthBottom != null) {
                                        anchors.put("lips", normPoint(mouthBottom.getPosition(), iw, ih));
                                    }
                                    try {
                                        FaceContour upper = best.getContour(FaceContour.UPPER_LIP_TOP);
                                        if (upper != null && upper.getPoints() != null && !upper.getPoints().isEmpty()) {
                                            float sx = 0f, sy = 0f;
                                            for (PointF pt : upper.getPoints()) { sx += pt.x; sy += pt.y; }
                                            anchors.put("upperLipTop", normPoint(new PointF(sx / upper.getPoints().size(), sy / upper.getPoints().size()), iw, ih));
                                        }
                                        FaceContour lower = best.getContour(FaceContour.LOWER_LIP_BOTTOM);
                                        if (lower != null && lower.getPoints() != null && !lower.getPoints().isEmpty()) {
                                            float sx = 0f, sy = 0f;
                                            for (PointF pt : lower.getPoints()) { sx += pt.x; sy += pt.y; }
                                            anchors.put("lowerLipBottom", normPoint(new PointF(sx / lower.getPoints().size(), sy / lower.getPoints().size()), iw, ih));
                                        }
                                        FaceContour faceC = best.getContour(FaceContour.FACE);
                                        if (faceC != null && faceC.getPoints() != null && !faceC.getPoints().isEmpty()) {
                                            PointF chin = faceC.getPoints().get(0);
                                            for (PointF pt : faceC.getPoints()) if (pt.y > chin.y) chin = pt;
                                            anchors.put("chin", normPoint(chin, iw, ih));
                                        }
                                    } catch (Exception ignored) {}
                                    out.put("anchors", anchors);

                                    double yaw = Math.abs(best.getHeadEulerAngleY());
                                    double roll = Math.abs(best.getHeadEulerAngleZ());
                                    double faceArea = ((double) Math.max(1, r.width()) * Math.max(1, r.height())) / Math.max(1.0, (double) iw * ih);
                                    double frontalPenalty = Math.min(28.0, yaw * 1.6) + Math.min(18.0, roll * 1.4);
                                    double densityBonus = Math.min(24.0, densePoints.length() * 0.12);
                                    double sizeScore = Math.max(0.0, Math.min(18.0, faceArea * 140.0));
                                    double qualityScore = Math.max(30.0, Math.min(98.0, 54.0 + densityBonus + sizeScore - frontalPenalty));
                                    String qualityLabel = qualityScore >= 78 ? "Excellent" : (qualityScore >= 58 ? "Good" : "Retake Recommended");
                                    String qualityGuide;
                                    if (qualityScore >= 78) {
                                        qualityGuide = "نقاط سبز و نواحی تمرینی با کیفیت خوب تنظیم شدند؛ حالا تست دقت را انجام بده و Before/After را بررسی کن.";
                                    } else if (qualityScore >= 58) {
                                        qualityGuide = "چهره تشخیص داده شد، اما برای دقت بالاتر روبه‌روتر بایست و نور را بهتر کن.";
                                    } else {
                                        qualityGuide = "دقت عکس پایین است؛ لطفاً عکس روبه‌رو، واضح و بدون چرخش بگیر تا نقاط دقیق‌تر روی صورت بیفتند.";
                                    }
                                    JSONObject quality = new JSONObject();
                                    quality.put("score", qualityScore);
                                    quality.put("label", qualityLabel);
                                    quality.put("densePoints", densePoints.length());
                                    quality.put("guide", qualityGuide);
                                    out.put("quality", quality);
                                    out.put("yaw", best.getHeadEulerAngleY());
                                    out.put("roll", best.getHeadEulerAngleZ());

                                    enrichWithFaceMesh(bitmap, out, iw, ih);
                                } catch (Exception e) { sendFaceMapFailure("map-error"); }
                                finally { detector.close(); }
                            })
                            .addOnFailureListener(e -> { detector.close(); sendFaceMapFailure("detector-failed"); });
                } catch (Exception e) { sendFaceMapFailure("decode-error"); }
            }).start();
        }


        private void enrichWithFaceMesh(Bitmap bitmap, JSONObject out, int iw, int ih) {
            FaceMeshDetector meshDetector = FaceMeshDetection.getClient(
                    new FaceMeshDetectorOptions.Builder()
                            .setUseCase(FaceMeshDetectorOptions.FACE_MESH)
                            .build());
            InputImage meshImage = InputImage.fromBitmap(bitmap, 0);
            meshDetector.process(meshImage)
                    .addOnSuccessListener(meshes -> {
                        try {
                            if (meshes != null && !meshes.isEmpty()) {
                                FaceMesh bestMesh = meshes.get(0);
                                int bestArea = bestMesh.getBoundingBox().width() * bestMesh.getBoundingBox().height();
                                for (FaceMesh m : meshes) {
                                    int a = m.getBoundingBox().width() * m.getBoundingBox().height();
                                    if (a > bestArea) { bestMesh = m; bestArea = a; }
                                }
                                Rect mr = bestMesh.getBoundingBox();
                                float fw = Math.max(1f, mr.width());
                                float cx = mr.exactCenterX();
                                float cy = mr.exactCenterY();

                                JSONObject mesh = new JSONObject();
                                mesh.put("source", "mlkit-face-mesh-468");
                                mesh.put("metric", false);
                                mesh.put("estimatedDepth", true);
                                JSONArray verts = new JSONArray();
                                for (FaceMeshPoint mp : bestMesh.getAllPoints()) {
                                    PointF3D pos = mp.getPosition();
                                    JSONObject v = new JSONObject();
                                    v.put("i", mp.getIndex());
                                    v.put("x", ((pos.getX() - cx) / fw) * 1.65f);
                                    v.put("y", ((cy - pos.getY()) / fw) * 1.65f);
                                    v.put("z", ((-pos.getZ()) / fw) * 1.65f);
                                    v.put("u", clamp01(pos.getX() / Math.max(1f, iw)));
                                    v.put("v", clamp01(pos.getY() / Math.max(1f, ih)));
                                    v.put("fu", clamp01((pos.getX() - mr.left) / fw));
                                    v.put("fv", clamp01((pos.getY() - mr.top) / Math.max(1f, mr.height())));
                                    verts.put(v);
                                }
                                JSONArray tris = new JSONArray();
                                for (Triangle<FaceMeshPoint> tri : bestMesh.getAllTriangles()) {
                                    List<FaceMeshPoint> tp = tri.getAllPoints();
                                    if (tp == null || tp.size() != 3) continue;
                                    JSONArray t = new JSONArray();
                                    t.put(tp.get(0).getIndex());
                                    t.put(tp.get(1).getIndex());
                                    t.put(tp.get(2).getIndex());
                                    tris.put(t);
                                }
                                mesh.put("points", verts);
                                mesh.put("triangles", tris);
                                mesh.put("pointCount", verts.length());
                                mesh.put("triangleCount", tris.length());
                                out.put("mesh3d", mesh);
                            }
                        } catch (Exception ignored) {}
                        sendFaceMap(out.toString());
                    })
                    .addOnFailureListener(e -> sendFaceMap(out.toString()))
                    .addOnCompleteListener(task -> meshDetector.close());
        }

        private JSONObject normPoint(PointF p, int w, int h) throws Exception {
            JSONObject o = new JSONObject();
            o.put("x", clamp01(p.x / Math.max(1f, w)));
            o.put("y", clamp01(p.y / Math.max(1f, h)));
            return o;
        }

        private double clamp01(double v) { return Math.max(0.0, Math.min(1.0, v)); }

        private void sendFaceMap(String json) {
            runOnUiThread(() -> {
                if (webView != null) webView.evaluateJavascript(
                        "window.FaceLabFaceMap && window.FaceLabFaceMap(" + JSONObject.quote(json) + ")", null);
            });
        }

        private void sendFaceMapFailure(String reason) {
            try {
                JSONObject o = new JSONObject(); o.put("ok", false); o.put("reason", reason); sendFaceMap(o.toString());
            } catch (Exception ignored) { sendFaceMap("{\"ok\":false}"); }
        }

        @JavascriptInterface
        public String securityStatus() {
            JSONObject out = new JSONObject();
            try {
                String installer = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try { installer = getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName(); }
                    catch (Exception ignored) {}
                } else {
                    try { installer = getPackageManager().getInstallerPackageName(getPackageName()); }
                    catch (Exception ignored) {}
                }
                String digest = currentSignerSha256();
                String expected = "F6EA3826BE6C467DA8A907160A19031620ED3A8CAB906B0AA7626FB6021E73FC";
                boolean valid = BuildConfig.DEBUG || expected.equalsIgnoreCase(digest);
                out.put("signatureValid", valid);
                out.put("installer", installer == null || installer.isEmpty() ? "direct / review" : installer);
                out.put("storeInstall", "com.farsitel.bazaar".equals(installer) || "ir.mservices.market".equals(installer));
                out.put("debug", BuildConfig.DEBUG);
            } catch (Exception e) {
                try { out.put("signatureValid", BuildConfig.DEBUG); out.put("installer", "unknown"); } catch (Exception ignored) {}
            }
            return out.toString();
        }

        private String currentSignerSha256() throws Exception {
            PackageInfo pi;
            byte[] cert;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi.signingInfo;
                Signature[] sigs = si == null ? null : si.getApkContentsSigners();
                if (sigs == null || sigs.length == 0) return "";
                cert = sigs[0].toByteArray();
            } else {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "";
                cert = pi.signatures[0].toByteArray();
            }
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(cert);
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format(Locale.US, "%02X", b));
            return sb.toString();
        }

        @JavascriptInterface
        public void startClinicalScan() {
            runOnUiThread(() -> {
                try {
                    ClinicalScanStore.clear();
                    Intent intent = new Intent(MainActivity.this, ClinicalScanActivity.class);
                    startActivityForResult(intent, CLINICAL_SCAN_REQUEST);
                } catch (Exception e) {
                    try {
                        JSONObject o = new JSONObject();
                        o.put("ok", false); o.put("reason", "scanner-launch-failed");
                        String payload = o.toString();
                        if (webView != null) webView.evaluateJavascript(
                                "window.FaceLabClinicalScanResult && window.FaceLabClinicalScanResult(" + JSONObject.quote(payload) + ")", null);
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void openFrontCamera() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    pendingNativeCamera = true;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
                    return;
                }
                launchFrontCameraInternal();
            });
        }

        @JavascriptInterface
        public void alertFeedback(final String level) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    boolean danger = "danger".equalsIgnoreCase(level);
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            if (danger) vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 70, 190}, -1));
                            else vibrator.vibrate(VibrationEffect.createOneShot(55L, 110));
                        } else {
                            if (danger) vibrator.vibrate(new long[]{0, 120, 70, 190}, -1);
                            else vibrator.vibrate(55L);
                        }
                    }
                    ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, danger ? 95 : 55);
                    if (danger) {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 160);
                        new android.os.Handler(getMainLooper()).postDelayed(() -> tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 190), 230);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 520);
                    } else {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70);
                        new android.os.Handler(getMainLooper()).postDelayed(tg::release, 130);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public boolean saveBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri != null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "در Pictures/FaceLab ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            }
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "ذخیره انجام نشد", Toast.LENGTH_LONG).show());
            return false;
        }

        @JavascriptInterface
        public boolean shareBase64Image(String dataUrl, String requestedName) {
            Uri uri = persistDataUrl(dataUrl, requestedName);
            if (uri == null) return false;
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "اشتراک نتیجه FACE LAB"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "اشتراک‌گذاری در دسترس نیست", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        private Uri persistDataUrl(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.contains(",")) return null;
                String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                String safeName = requestedName;
                if (safeName == null || safeName.trim().isEmpty()) {
                    safeName = "FaceLab_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
                }
                if (!safeName.toLowerCase(Locale.US).endsWith(".png")) safeName += ".png";

                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceLab");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) return null;
                    os.write(bytes);
                    os.flush();
                }
                return uri;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
